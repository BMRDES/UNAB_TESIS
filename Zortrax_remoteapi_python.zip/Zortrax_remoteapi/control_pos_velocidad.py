''' Librerias para funciones asociadas'''

import sim
import numpy as np
import time
import math
import goto

integral = 0
errortotal = 0

""" Definir la funcion de conexion con CoppeliaSim"""
def connect(port) :

    #Establece la conexion con coppeliaSim
    #port debe coincidir con el puerto de conexion de coppeliaSim
    #retorna el numero de cliente ID 0 -1 si no puede establecer la comunicacion
    sim.simxFinish(-1) #En caso de cerrar la conexion
    clientID = sim.simxStart('127.0.0.1', port, True, True, 2000, 5) #Conexion
    if clientID == 0:
        print("conectado a", port)
    else:
        print("No se pudo conectar")
    return clientID

""" Conexion con el puerto 19999""" # Conectarse al servidor de Coppelia
clientID = connect(19999)

""" Funcion posicion original (REPOSO)"""
 
    
# FUNCION MANEJADOR PARA EL EFECTOR FINAL DEL ZORTRAX
returnCode,handle=sim.simxGetObjectHandle(clientID,'efector',sim.simx_opmode_blocking)
efector = handle
print(efector)

# OBTENER POSICION DEL OBJETO: EFECTOR
returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
print('pos en x,y,z', pos_efector)

# FUNCION MANEJADOR PARA CADA GRADO DE LIBERTAD
ret,Zortrax_j1 = sim.simxGetObjectHandle(clientID,'Zortrax_j1',sim.simx_opmode_blocking)
ret,Zortrax_j2 = sim.simxGetObjectHandle(clientID,'Zortrax_j2',sim.simx_opmode_blocking)
ret,Zortrax_j3 = sim.simxGetObjectHandle(clientID,'Zortrax_j3',sim.simx_opmode_blocking)
print(Zortrax_j1, Zortrax_j2, Zortrax_j3)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 10, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 10, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 10, sim.simx_opmode_blocking)



# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Asignacion de variables de proceso
pv1 = pos1
pv2 = pos2
pv3 = pos3


print('PV1 =  ',pos1)   
print('PV2 =  ',pos2)   
print('PV3 =  ',pos3)   

'''Primer PUNTO TRAYECTORIA'''
sp1 = -90.0 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 0.0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = 0.0 * (3.1416/180); print('Referencia 3:' ,sp3)

error1 = sp1 - pv1
error2 = sp2 - pv2
error3 = sp3 - pv3

print('error1 =  ',error1)   
print('error2 =  ',error2)   
print('error3 =  ',error3)  
n = 0

promerr = (error1+error2+error3)/3
print('Error promedio =  ', promerr)


start = time.time()
while ((promerr != 0.01)) and n <40: 
            
            
            '''and n <50'''
            s1 = error1 * 0.5
            s2 = error2 * 0.5
            s3 = error3 * 0.5
            
           

            
                
            returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, s1, sim.simx_opmode_blocking)
            returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, s2, sim.simx_opmode_blocking)
            returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, s3, sim.simx_opmode_blocking)
        
            returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
            returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
            returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
            # PRIMER PUNTO DE TRAYECTORIA
            
            error1 = sp1 - pos1
            error2 = sp2 - pos2
            error3 = sp3 - pos3
        
            print('Calculo de nuevo error1 =  ',error1 )
            print('Calculo de nuevo error2 =  ',error2 )
            print('Calculo de nuevo error3 =  ',error3 )
    
            promerr = (error1+error2+error3)/3
            
            print('Error promedio =  ', promerr)
            
            n = n+1
            print('Iteracion actual:  ',n)
     
        
print('Salio del while')
end = time.time()
tiempo = (end - start)
print('Tiempo transcurrido:  ',tiempo)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 0, sim.simx_opmode_blocking)
time.sleep(3)

# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Asignacion de variables de proceso
pv1 = pos1
pv2 = pos2
pv3 = pos3


print('PV1 =  ',pos1)   
print('PV2 =  ',pos2)   
print('PV3 =  ',pos3)  

'''SEGUNDO PUNTO TRAYECTORIA'''
sp1 = 0.0 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 90.0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = 20.0 * (3.1416/180); print('Referencia 3:' ,sp3)

error1 = sp1 - pv1
error2 = sp2 - pv2
error3 = sp3 - pv3

print('error1 =  ',error1)   
print('error2 =  ',error2)   
print('error3 =  ',error3)  
n = 0

promerr = (error1+error2+error3)/3
print('Error promedio =  ', promerr)


start = time.time()
while ((promerr != 0.01)) and n <10:
            s1 = error1 * 0.5
            s2 = error2 * 0.5
            s3 = error3 * 0.5
                
            returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, s1, sim.simx_opmode_blocking)
            returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, s2, sim.simx_opmode_blocking)
            returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, s3, sim.simx_opmode_blocking)
        
            returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
            returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
            returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
            # PRIMER PUNTO DE TRAYECTORIA
            
            error1 = sp1 - pos1
            error2 = sp2 - pos2
            error3 = sp3 - pos3
        
            print('Calculo de nuevo error1 =  ',error1 )
            print('Calculo de nuevo error2 =  ',error2 )
            print('Calculo de nuevo error3 =  ',error3 )
    
            promerr = (error1+error2+error3)/3
            print('Error promedio =  ', promerr)
            
            n = n+1
            print('Iteracion actual:  ',n)
     
        
print('Salio del while')
end = time.time()
tiempo = (end - start)
print('Tiempo transcurrido:  ',tiempo)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 0, sim.simx_opmode_blocking)
time.sleep(3)
# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Asignacion de variables de proceso
pv1 = pos1
pv2 = pos2
pv3 = pos3


print('PV1 =  ',pos1)   
print('PV2 =  ',pos2)   
print('PV3 =  ',pos3)  

'''Tercer PUNTO TRAYECTORIA'''
sp1 = 90.0 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 0.0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = 20.0 * (3.1416/180); print('Referencia 3:' ,sp3)

error1 = sp1 - pv1
error2 = sp2 - pv2
error3 = sp3 - pv3

print('error1 =  ',error1)   
print('error2 =  ',error2)   
print('error3 =  ',error3)  
n = 0

promerr = (error1+error2+error3)/3
print('Error promedio =  ', promerr)

start = time.time()
while ((promerr != 0.01))and n <80:
            s1 = error1 * 0.1
            s2 = error2 * 0.1
            s3 = error3 * 0.1
                
            returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, s1, sim.simx_opmode_blocking)
            returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, s2, sim.simx_opmode_blocking)
            returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, s3, sim.simx_opmode_blocking)
        
            returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
            returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
            returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
            # PRIMER PUNTO DE TRAYECTORIA
            
            error1 = sp1 - pos1
            error2 = sp2 - pos2
            error3 = sp3 - pos3
        
            print('Calculo de nuevo error1 =  ',error1 )
            print('Calculo de nuevo error2 =  ',error2 )
            print('Calculo de nuevo error3 =  ',error3 )
    
            promerr = (error1+error2+error3)/3
            print('Error promedio =  ', promerr)
            
            n = n+1
            print('Iteracion actual:  ',n)
     
        
print('Salio del while')
end = time.time()
tiempo = (end - start)
print('Tiempo transcurrido:  ',tiempo)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 0, sim.simx_opmode_blocking)
time.sleep(3)

# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Asignacion de variables de proceso
pv1 = pos1
pv2 = pos2
pv3 = pos3


print('PV1 =  ',pos1)   
print('PV2 =  ',pos2)   
print('PV3 =  ',pos3)  

'''Tercer PUNTO TRAYECTORIA'''
sp1 = -90.0 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 90.0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = -90 * (3.1416/180); print('Referencia 3:' ,sp3)

error1 = sp1 - pv1
error2 = sp2 - pv2
error3 = sp3 - pv3

print('error1 =  ',error1)   
print('error2 =  ',error2)   
print('error3 =  ',error3)  
n = 0

promerr = (error1+error2+error3)/3
print('Error promedio =  ', promerr)

start = time.time()
while ((promerr != 0.01)) and n <100:
            s1 = error1 * 0.1
            s2 = error2 * 0.1
            s3 = error3 * 0.1
                
            returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, s1, sim.simx_opmode_blocking)
            returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, s2, sim.simx_opmode_blocking)
            returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, s3, sim.simx_opmode_blocking)
        
            returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
            returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
            returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
            # PRIMER PUNTO DE TRAYECTORIA
            
            error1 = sp1 - pos1
            error2 = sp2 - pos2
            error3 = sp3 - pos3
        
            print('Calculo de nuevo error1 =  ',error1 )
            print('Calculo de nuevo error2 =  ',error2 )
            print('Calculo de nuevo error3 =  ',error3 )
    
            promerr = (error1+error2+error3)/3
            print('Error promedio =  ', promerr)
            
            n = n+1
            print('Iteracion actual:  ',n)
     
        
print('Salio del while')
end = time.time()
tiempo = (end - start)
print('Tiempo transcurrido:  ',tiempo)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 0, sim.simx_opmode_blocking)

# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Asignacion de variables de proceso
pv1 = pos1
pv2 = pos2
pv3 = pos3


print('PV1 =  ',pos1)   
print('PV2 =  ',pos2)   
print('PV3 =  ',pos3)   

'''Ultimo PUNTO TRAYECTORIA'''
sp1 = -90.0 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 90.0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = -90.0 * (3.1416/180); print('Referencia 3:' ,sp3)

error1 = sp1 - pv1
error2 = sp2 - pv2
error3 = sp3 - pv3

print('error1 =  ',error1)   
print('error2 =  ',error2)   
print('error3 =  ',error3)  
n = 0

promerr = (error1+error2+error3)/3
print('Error promedio =  ', promerr)

start = time.time()
while ((promerr != 0.01))and n <100:
            s1 = error1 * 0.5
            s2 = error2 * 0.5
            s3 = error3 * 0.5
                
            returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, s1, sim.simx_opmode_blocking)
            returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, s2, sim.simx_opmode_blocking)
            returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, s3, sim.simx_opmode_blocking)
        
            returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
            returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
            returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
            # PRIMER PUNTO DE TRAYECTORIA
            
            error1 = sp1 - pos1
            error2 = sp2 - pos2
            error3 = sp3 - pos3
        
            print('Calculo de nuevo error1 =  ',error1 )
            print('Calculo de nuevo error2 =  ',error2 )
            print('Calculo de nuevo error3 =  ',error3 )
    
            promerr = (error1+error2+error3)/3
            print('Error promedio =  ', promerr)
            
            n = n+1
            print('Iteracion actual:  ',n)
     
        
print('Salio del while')
end = time.time()
tiempo = (end - start)
print('Tiempo transcurrido:  ',tiempo)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 0, sim.simx_opmode_blocking)
time.sleep(3)

# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Asignacion de variables de proceso
pv1 = pos1
pv2 = pos2
pv3 = pos3


print('PV1 =  ',pos1)   
print('PV2 =  ',pos2)   
print('PV3 =  ',pos3)   

'''Ultimo PUNTO TRAYECTORIA'''
sp1 = 90.0 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 90.0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = -90.0 * (3.1416/180); print('Referencia 3:' ,sp3)

error1 = sp1 - pv1
error2 = sp2 - pv2
error3 = sp3 - pv3

print('error1 =  ',error1)   
print('error2 =  ',error2)   
print('error3 =  ',error3)  
n = 0

promerr = (error1+error2+error3)/3
print('Error promedio =  ', promerr)

start = time.time()
while ((promerr != 0.01))and n <100:
            s1 = error1 * 0.5
            s2 = error2 * 0.5
            s3 = error3 * 0.5
                
            returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, s1, sim.simx_opmode_blocking)
            returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, s2, sim.simx_opmode_blocking)
            returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, s3, sim.simx_opmode_blocking)
        
            returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
            returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
            returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
            # PRIMER PUNTO DE TRAYECTORIA
            
            error1 = sp1 - pos1
            error2 = sp2 - pos2
            error3 = sp3 - pos3
        
            print('Calculo de nuevo error1 =  ',error1 )
            print('Calculo de nuevo error2 =  ',error2 )
            print('Calculo de nuevo error3 =  ',error3 )
    
            promerr = (error1+error2+error3)/3
            print('Error promedio =  ', promerr)
            
            n = n+1
            print('Iteracion actual:  ',n)
     
        
print('Salio del while')
end = time.time()
tiempo = (end - start)
print('Tiempo transcurrido:  ',tiempo)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 0, sim.simx_opmode_blocking)
time.sleep(3)