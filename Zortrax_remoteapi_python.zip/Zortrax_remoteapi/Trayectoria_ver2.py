#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 18:12:16 2021

@author: bmr MACoS
"""
""" @author: Braulio
"""
'''Importar las librerias asociadas a la comunicacion'''

import sim
import numpy as np
import time



""" Definir la funcion de conexion con CoppeliaSim"""
def connect(port) :

    #Establece la conexion con coppeliaSim
    #port debe coincidir con el puerto de conexion de coppeliaSim
    #retorna el numero de cliente ID 0 -1 si no puede establecer la comunicacion
    sim.simxFinish(-1) #En caso de cerrar la conexion
    clientID = sim.simxStart('127.0.0.1', port, True, True, 2000, 5) #Conexion
    if clientID == 0:
        print("conectado a", port)
    else:
        print("No se pudo conectar")
    return clientID

""" Conexion con el puerto 19999""" # Conectarse al servidor de Coppelia
clientID = connect(19999)

""" Funcion posicion original (REPOSO)"""
 
    
# FUNCION MANEJADOR PARA EL EFECTOR FINAL DEL ZORTRAX
returnCode,handle=sim.simxGetObjectHandle(clientID,'efector',sim.simx_opmode_blocking)
efector = handle
print(efector)

# OBTENER POSICION DEL OBJETO: EFECTOR
returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
print('pos en x,y,z', pos_efector)

# fUNCION MANEJADOR PARA CADA GRADO DE LIBERTAD
ret,Zortrax_j1 = sim.simxGetObjectHandle(clientID,'Zortrax_j1',sim.simx_opmode_blocking)
ret,Zortrax_j2 = sim.simxGetObjectHandle(clientID,'Zortrax_j2',sim.simx_opmode_blocking)
ret,Zortrax_j3 = sim.simxGetObjectHandle(clientID,'Zortrax_j3',sim.simx_opmode_blocking)
print(Zortrax_j1, Zortrax_j2, Zortrax_j3)
#Escribir coordinadas articulares en radianes
q1 = 90 * np.pi/180
q2 = 90 * np.pi/180 
q3 = -90 * np.pi/180
# la pos de x= 0.28, y= 0.09, z= 0.368 para esos valores articulares
#Escribir valores articulares para los tres grados de libertad
returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
time.sleep(5)



def trayectoria_1():
    
    # PRIMER PUNTO DE TRAYECTORIA
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    q1 = 0 * np.pi/180
    q2 = 0 * np.pi/180 
    q3 = 0 * np.pi/180
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    # Mostrar valores actuales
    print('pos_rad q1', round(returnCode_q1))
    print('pos_rad q2', round(returnCode_q2))
    print('pos_rad q3', round(returnCode_q3))
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)
    time.sleep(5)

def trayectoria_2():
    # SEGUNDO PUNTO DE TRAYECTORIA
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    q1 = 0 * np.pi/180
    q2 = 90 * np.pi/180 
    q3 = 20 * np.pi/180
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    # Mostrar valores actuales
    print('pos_rad q1', round(returnCode_q1))
    print('pos_rad q2', round(returnCode_q2))
    print('pos_rad q3', round(returnCode_q3))
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)
    time.sleep(5)
    
def trayectoria_3():
    #TERCER PUNTO TRAYECTORIA
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    q1 = 90 * np.pi/180
    q2 = 90 * np.pi/180 
    q3 = 20 * np.pi/180
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    # Mostrar valores actuales
    print('pos_rad q1', round(returnCode_q1))
    print('pos_rad q2', round(returnCode_q2))
    print('pos_rad q3', round(returnCode_q3))
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)
    time.sleep(5)
    
def trayectoria_4():
    #CUARTO PUNTO TRAYECTORIA
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    q1 = 90 * np.pi/180
    q2 = 0 * np.pi/180 
    q3 = 20 * np.pi/180
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    # Mostrar valores actuales
    print('pos_rad q1', round(returnCode_q1))
    print('pos_rad q2', round(returnCode_q2))
    print('pos_rad q3', round(returnCode_q3))
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)
    time.sleep(5)    
    
def trayectoria_5():
    #QUINTO PUNTO DE TRAYECTORIA
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    q1 = 90 * np.pi/180
    q2 = 90 * np.pi/180 
    q3 = 20 * np.pi/180
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    # Mostrar valores actuales
    print('pos_rad q1', round(returnCode_q1))
    print('pos_rad q2', round(returnCode_q2))
    print('pos_rad q3', round(returnCode_q3))
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)
    time.sleep(5)    
    
def trayectoria_6():
    # SEXTO PUNTO DE TRAYECTORIA
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    q1 = 0 * np.pi/180
    q2 = 90 * np.pi/180 
    q3 = 20 * np.pi/180
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    # Mostrar valores actuales
    print('pos_rad q1', round(returnCode_q1))
    print('pos_rad q2', round(returnCode_q2))
    print('pos_rad q3', round(returnCode_q3))
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)   
    time.sleep(5)    

def trayectoria_7():
  # SEPTIMO PUNTO DE TRAYECTORIA
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    q1 = 0 * np.pi/180
    q2 = 0 * np.pi/180 
    q3 = 0 * np.pi/180
    # Escribir la posicion del robot en RADIANES , articulacion I -II-III   
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    # Mostrar valores actuales
    print('pos_rad q1', round(returnCode_q1))
    print('pos_rad q2', round(returnCode_q2))
    print('pos_rad q3', round(returnCode_q3))
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)
    time.sleep(5)
    

    
    
i=0

while (i<3):
    '''Trayectoria 1'''
    trayectoria_1()
    
    '''Trayectoria 2'''
    trayectoria_2()
    
    '''Trayectoria 3'''
    trayectoria_3()

    '''Trayectoria 4'''
    trayectoria_4()
    
    '''Trayectoria 5'''    
    trayectoria_5()
    
    '''Trayectoria 6'''    
    trayectoria_6()
    
    '''Trayectoria 7'''    
    trayectoria_7()
    
    returnCode,handle=sim.simxGetObjectHandle(clientID,'efector',sim.simx_opmode_blocking)
    efector = handle
    print(efector)

    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    print('pos en x,y,z', pos_efector)

    # fUNCION MANEJADOR PARA CADA GRADO DE LIBERTAD
    ret,Zortrax_j1 = sim.simxGetObjectHandle(clientID,'Zortrax_j1',sim.simx_opmode_blocking)
    ret,Zortrax_j2 = sim.simxGetObjectHandle(clientID,'Zortrax_j2',sim.simx_opmode_blocking)
    ret,Zortrax_j3 = sim.simxGetObjectHandle(clientID,'Zortrax_j3',sim.simx_opmode_blocking)
    print(Zortrax_j1, Zortrax_j2, Zortrax_j3)
    #Escribir coordinadas articulares en radianes
    q1 = 0 * np.pi/180
    q2 = 90 * np.pi/180 
    q3 = -90 * np.pi/180
    # la pos de x= 0.28, y= 0.09, z= 0.368 para esos valores articulares
    #Escribir valores articulares para los tres grados de libertad
    returnCode_q1 = sim.simxSetJointTargetPosition(clientID, Zortrax_j1, q1, sim.simx_opmode_oneshot)
    returnCode_q2 = sim.simxSetJointTargetPosition(clientID, Zortrax_j2, q2, sim.simx_opmode_oneshot)
    returnCode_q3 = sim.simxSetJointTargetPosition(clientID, Zortrax_j3, q3, sim.simx_opmode_oneshot)
    time.sleep(5)
    i=i+1
    print('Iteracion actual',i)

print('Trayectoria terminada')
    
