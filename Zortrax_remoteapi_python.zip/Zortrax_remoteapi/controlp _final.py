#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" @author: Braulio """
'''Importar las librerias asociadas a la comunicacion'''

import sim
import numpy as np
import time
import math

'''----------------VARIABLES GLOBALES-----------'''

sp1 = 0
sp2 = 0
sp3 = 0

err1=0
err2=0
err3=0

erroractual1 = 0
erroractual2 = 0
erroractual3 = 0

integral1=0
integral2=0
integral3=0

erroranterior1 = 0.0
erroranterior2 = 0.0
erroranterior3 = 0.0

KP1 = 5.73663496461823
KP2 = 5.73663496461823
KP3 = 5.73663496461823

Ti1 = 31.08
Ti2 = 31.08
Ti3 = 31.08

pv1 = 0
pv2 = 0
pv3 = 0

pos1 = 0
pos2 = 0
pos3 = 0

control1 = 0
control2 = 0
control3 = 0

q1 = 0
q2 = 0
q3 = 0

sensor1 = 0
sensor2 = 0
sensor3 = 0


""" Definir la funcion de conexion con CoppeliaSim"""
def connect(port) :

    #Establece la conexion con coppeliaSim
    #port debe coincidir con el puerto de conexion de coppeliaSim
    #retorna el numero de cliente ID 0 -1 si no puede establecer la comunicacion
    sim.simxFinish(-1) #En caso de cerrar la conexion
    clientID = sim.simxStart('127.0.0.1', port, True, True, 2000, 5) #Conexion
    if clientID == 0:
        print("conectado a", port)
    else:
        print("No se pudo conectar")
    return clientID

""" Conexion con el puerto 19999""" # Conectarse al servidor de Coppelia
clientID = connect(19999)

""" Funcion posicion original (REPOSO)"""
 
    
# FUNCION MANEJADOR PARA EL EFECTOR FINAL DEL ZORTRAX
returnCode,handle=sim.simxGetObjectHandle(clientID,'efector',sim.simx_opmode_blocking)
efector = handle
print(efector)

# OBTENER POSICION DEL OBJETO: EFECTOR
returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
print('pos en x,y,z', pos_efector)

# fUNCION MANEJADOR PARA CADA GRADO DE LIBERTAD
ret,Zortrax_j1 = sim.simxGetObjectHandle(clientID,'Zortrax_j1',sim.simx_opmode_blocking)
ret,Zortrax_j2 = sim.simxGetObjectHandle(clientID,'Zortrax_j2',sim.simx_opmode_blocking)
ret,Zortrax_j3 = sim.simxGetObjectHandle(clientID,'Zortrax_j3',sim.simx_opmode_blocking)
print(Zortrax_j1, Zortrax_j2, Zortrax_j3)

# Escribir la velocidad
returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, 0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, 0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, 0, sim.simx_opmode_blocking)
    

# la pos de x= 0.28, y= 0.09, z= 0.368 para esos valores articulares
#Escribir valores articulares para los tres grados de libertad

    
# PRIMER PUNTO DE TRAYECTORIA
''' Asignacion Setpoint'''
sp1 = 90 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)

# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Conversion a rad
pv1 = pos1
pv2 = pos2
pv3 = pos3

print ("posicion inicial: ", pos1)
''' INICIO RUTINA CONTROL PID DISCRETO'''
''' Calculo de error'''

err1 = sp1 - pv1
err2 = sp2 - pv2
err3 = sp3 - pv3

print('error1= ',err1)
print('error2= ',err2)
print('error3= ',err3)    

while (((err1) < -0.01  ) and ((err2) < -0.01)  and ((err3) < -0.01)):
    
    # PRIMER PUNTO DE TRAYECTORIA
    ''' Asignacion Setpoint'''
    sp1 = 90 * (3.1416/180); print('Referencia 1:' ,sp1)
    sp2 = 0 * (3.1416/180); print('Referencia 2:' ,sp2)
    sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)


    
    # LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    
    # Conversion a rad
    pv1 = pos1
    pv2 = pos2
    pv3 = pos3

    err1 = sp1 - pos1

    err2 = sp2 - pos2
    
    err3 = sp3 - pos3
    


    ''' CONTROL P'''
    control_p1 = (0.1 * err1)
    control_p2 = (0.1 * err2)
    control_p3 = (0.1 * err3)
    
    print('Señal de control 1: ',control_p1)
    print('Señal de control 2: ',control_p2)
    print('Señal de control 3: ',control_p3)
    

        
    # Escribir la velocidad
    returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, control_p1, sim.simx_opmode_blocking)
    returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, control_p2, sim.simx_opmode_blocking)
    returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, control_p3, sim.simx_opmode_blocking)
    
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    #print('Valores actuales del robot')
    #print(pos1)
    #print(pos2)
    #print(pos3)
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    #print('pos en x,y,z', pos_efector)



# Segundo PUNTO DE TRAYECTORIA
''' Asignacion Setpoint'''
sp1 = 90 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 90 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)

# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Conversion a rad
pv1 = pos1
pv2 = pos2
pv3 = pos3

print ("posicion inicial: ", pos1)
''' INICIO RUTINA CONTROL PID DISCRETO'''
''' Calculo de error'''

err1 = sp1 - pv1
err2 = sp2 - pv2
err3 = sp3 - pv3

print('error1= ',err1)
print('error2= ',err2)
print('error3= ',err3)    

while (((err1) < -0.01  ) and ((err2) < -0.01)  and ((err3) < -0.01)):
    
    # Segundo PUNTO DE TRAYECTORIA
    ''' Asignacion Setpoint'''
    sp1 = 90 * (3.1416/180); print('Referencia 1:' ,sp1)
    sp2 = 90 * (3.1416/180); print('Referencia 2:' ,sp2)
    sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)


    
    # LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    
    # Conversion a rad
    pv1 = pos1
    pv2 = pos2
    pv3 = pos3

    err1 = sp1 - pos1

    err2 = sp2 - pos2
    
    err3 = sp3 - pos3
    


    ''' CONTROL P'''
    control_p1 = (0.1 * err1)
    control_p2 = (0.1 * err2)
    control_p3 = (0.1 * err3)
    
    print('Señal de control 1: ',control_p1)
    print('Señal de control 2: ',control_p2)
    print('Señal de control 3: ',control_p3)
    

        
    # Escribir la velocidad
    returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, control_p1, sim.simx_opmode_blocking)
    returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, control_p2, sim.simx_opmode_blocking)
    returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, control_p3, sim.simx_opmode_blocking)
    
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    #print('Valores actuales del robot')
    #print(pos1)
    #print(pos2)
    #print(pos3)
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    #print('pos en x,y,z', pos_efector)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1,0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2,0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3,0, sim.simx_opmode_blocking)


print('Trayectoria1 terminada')
print("posicion final: ", pos1)
print(err1)

# Tercer PUNTO DE TRAYECTORIA
''' Asignacion Setpoint'''
sp1 = 45 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 45 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)

# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Conversion a rad
pv1 = pos1
pv2 = pos2
pv3 = pos3

print ("posicion inicial: ", pos1)
''' INICIO RUTINA CONTROL PID DISCRETO'''
''' Calculo de error'''

err1 = sp1 - pv1
err2 = sp2 - pv2
err3 = sp3 - pv3

print('error1= ',err1)
print('error2= ',err2)
print('error3= ',err3)    

while (((err1) < -0.01  ) and ((err2) < -0.01)  and ((err3) < -0.01)):
    
    # PRIMER PUNTO DE TRAYECTORIA
    ''' Asignacion Setpoint'''
    sp1 = 45 * (3.1416/180); print('Referencia 1:' ,sp1)
    sp2 = 45 * (3.1416/180); print('Referencia 2:' ,sp2)
    sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)


    
    # LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    
    # Conversion a rad
    pv1 = pos1
    pv2 = pos2
    pv3 = pos3

    err1 = sp1 - pos1

    err2 = sp2 - pos2
    
    err3 = sp3 - pos3
    


    ''' CONTROL P'''
    control_p1 = (0.1 * err1)
    control_p2 = (0.1 * err2)
    control_p3 = (0.1 * err3)
    
    print('Señal de control 1: ',control_p1)
    print('Señal de control 2: ',control_p2)
    print('Señal de control 3: ',control_p3)
    

        
    # Escribir la velocidad
    returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, control_p1, sim.simx_opmode_blocking)
    returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, control_p2, sim.simx_opmode_blocking)
    returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, control_p3, sim.simx_opmode_blocking)
    
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    #print('Valores actuales del robot')
    #print(pos1)
    #print(pos2)
    #print(pos3)
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    #print('pos en x,y,z', pos_efector)
# PRIMER PUNTO DE TRAYECTORIA
''' Asignacion Setpoint'''
sp1 = 90 * (3.1416/180); print('Referencia 1:' ,sp1)
sp2 = 0 * (3.1416/180); print('Referencia 2:' ,sp2)
sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)

# LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
# LEER LA POSICION DE DE LA ARTICULACION I - II - III
returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)

# Conversion a rad
pv1 = pos1
pv2 = pos2
pv3 = pos3

print ("posicion inicial: ", pos1)
''' INICIO RUTINA CONTROL PID DISCRETO'''
''' Calculo de error'''

err1 = sp1 - pv1
err2 = sp2 - pv2
err3 = sp3 - pv3

print('error1= ',err1)
print('error2= ',err2)
print('error3= ',err3)    

while (((err1) < -0.01  ) and ((err2) < -0.01)  and ((err3) < -0.01)):
    
    # PRIMER PUNTO DE TRAYECTORIA
    ''' Asignacion Setpoint'''
    sp1 = 90 * (3.1416/180); print('Referencia 1:' ,sp1)
    sp2 = 0 * (3.1416/180); print('Referencia 2:' ,sp2)
    sp3 = 0 * (3.1416/180); print('Referencia 3:' ,sp3)


    
    # LAS FUNCIONES TRIGONOMETRICAS RABAJAN EN RADIANES     
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    
    # Conversion a rad
    pv1 = pos1
    pv2 = pos2
    pv3 = pos3

    err1 = sp1 - pos1

    err2 = sp2 - pos2
    
    err3 = sp3 - pos3
    


    ''' CONTROL P'''
    control_p1 = (0.1 * err1)
    control_p2 = (0.1 * err2)
    control_p3 = (0.1 * err3)
    
    print('Señal de control 1: ',control_p1)
    print('Señal de control 2: ',control_p2)
    print('Señal de control 3: ',control_p3)
    

        
    # Escribir la velocidad
    returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1, control_p1, sim.simx_opmode_blocking)
    returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2, control_p2, sim.simx_opmode_blocking)
    returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3, control_p3, sim.simx_opmode_blocking)
    
    # LEER LA POSICION DE DE LA ARTICULACION I - II - III
    returnCode, pos1 = sim.simxGetJointPosition(clientID, Zortrax_j1, sim.simx_opmode_blocking)
    returnCode, pos2 = sim.simxGetJointPosition(clientID, Zortrax_j2, sim.simx_opmode_blocking)
    returnCode, pos3 = sim.simxGetJointPosition(clientID, Zortrax_j3, sim.simx_opmode_blocking)
    #print('Valores actuales del robot')
    #print(pos1)
    #print(pos2)
    #print(pos3)
    # OBTENER POSICION DEL OBJETO: EFECTOR
    returnCode,pos_efector=sim.simxGetObjectPosition(clientID, efector, -1, sim.simx_opmode_blocking)
    #print('pos en x,y,z', pos_efector)

returnCode_v1 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j1,0, sim.simx_opmode_blocking)
returnCode_v2 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j2,0, sim.simx_opmode_blocking)
returnCode_v3 = sim.simxSetJointTargetVelocity(clientID, Zortrax_j3,0, sim.simx_opmode_blocking)


print('Trayectoria1 terminada')
print("posicion final: ", pos1)
print(err1)

 
# la pos de x= 0.28, y= 0.09, z= 0.368 para esos valores articulares
#Escribir valores articulares para los tres grados de libertad
